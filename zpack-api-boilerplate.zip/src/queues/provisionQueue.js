import { Queue } from 'bullmq';
import { redisOptions } from '../utils/redis.js';

export const provisionQueue = new Queue('provision', {
  connection: redisOptions
});
