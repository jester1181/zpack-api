import { Worker } from 'bullmq';
import { redisOptions } from '../utils/redis.js';
import { runProvisionPlaybook } from '../ansible/runProvision.js';

const worker = new Worker('provision', async job => {
  console.log(`Processing job ${job.id}`);
  await runProvisionPlaybook(job.data);
}, { connection: redisOptions });

worker.on('completed', job => {
  console.log(`Job ${job.id} completed`);
});

worker.on('failed', (job, err) => {
  console.error(`Job ${job.id} failed:`, err);
});
