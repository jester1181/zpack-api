import './src/jobs/provisionWorker.js';
